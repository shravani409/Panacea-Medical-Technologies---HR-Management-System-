from django.shortcuts import render


def home(request):
    return render(request, "landing.html")


def about(request):
    return render(request, "about.html")


def technology(request):
    return render(request, "technology.html")


def products(request):
    return render(request, "products.html")


def videos(request):
    return render(request, "videos.html")


def contact(request):
    return render(request, "contact.html")
