from django.urls import path
from . import views

app_name = "website"

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("technology/", views.technology, name="technology"),
    path("products/", views.products, name="products"),
    path("videos/", views.videos, name="videos"),
    path("contact/", views.contact, name="contact"),
]
