import re
from datetime import date, time, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db.models import Q
from django.db import transaction

from hr.models import (
    Attendance,
    Certificate,
    Employee,
    Event,
    Internship,
    Meeting,
    Payroll,
)


TARGET_COUNT = 30
EMPLOYEE_SEED_DATA = [
    ("Rahul Kumar", "Human Resources", "HR Executive"),
    ("Priya Patel", "Finance & Accounts", "Accountant"),
    ("Amit Kumar", "Software Development", "Software Developer"),
    ("Sneha Reddy", "IT Support", "IT Support Engineer"),
    ("Arjun Mehta", "Research & Development", "Research Engineer"),
    ("Divya Sharma", "Production", "Production Engineer"),
    ("Kiran Kumar", "Quality Assurance", "Quality Control Engineer"),
    ("Anjali Verma", "Quality Assurance", "Quality Assurance Executive"),
    ("Rohit Singh", "Mechanical Engineering", "Mechanical Design Engineer"),
    ("Pooja Nair", "Electrical Engineering", "Electrical Engineer"),
    ("Vikram Rao", "Electronics", "Electronics Engineer"),
    ("Neha Gupta", "Biomedical Engineering", "Biomedical Engineer"),
    ("Suresh Kumar", "Manufacturing", "Manufacturing Supervisor"),
    ("Kavya Reddy", "Supply Chain", "Supply Chain Executive"),
    ("Manoj Patel", "Purchase", "Purchase Officer"),
    ("Lakshmi Devi", "Stores & Inventory", "Store Keeper"),
    ("Sanjay Verma", "Service & Maintenance", "Service Engineer"),
    ("Swathi Rao", "Installation", "Installation Engineer"),
    ("Akash Sharma", "Customer Support", "Customer Support Executive"),
    ("Deepika Nair", "Sales & Marketing", "Sales Executive"),
    ("Naveen Kumar", "Business Development", "Business Development Executive"),
    ("Aishwarya Singh", "Regulatory Affairs", "Regulatory Affairs Executive"),
    ("Praveen Reddy", "Clinical Applications", "Clinical Application Specialist"),
    ("Meena Kumari", "Project Management", "Project Engineer"),
    ("Ramesh Babu", "Administration", "Administrative Officer"),
    ("Harsha Patel", "Documentation", "Documentation Executive"),
    ("Nithya Sharma", "Testing", "Test Engineer"),
    ("Abhishek Gupta", "Field Service", "Field Service Engineer"),
    ("Keerthi Rao", "Security", "Security Officer"),
    ("Dhanush B M", "Management", "Operations Manager"),
]
DEPARTMENTS = tuple(dict.fromkeys(dept for _, dept, _ in EMPLOYEE_SEED_DATA))
LOCATIONS = ("Malur", "Bengaluru", "Mysuru", "Hubballi")
COLLEGES = (
    "Engineering College - Bengaluru",
    "Applied Science College - Mysuru",
    "Technology Institute - Hubballi",
    "Health Sciences College - Tumakuru",
    "Polytechnic Institute - Mandya",
    "Medical Physics Institute - Hassan",
)
EVENT_THEMES = ("Radiotherapy Systems", "Quality Assurance", "Clinical Engineering", "Medical Imaging", "Patient Positioning", "Service Readiness")
EVENT_FORMATS = ("Orientation", "Workshop", "Review", "Planning Session", "Safety Briefing")
MEETING_TEAMS = ("Engineering", "Clinical Systems", "Quality", "Service", "People Operations")
MEETING_TOPICS = ("Quarterly Planning", "Equipment Readiness", "Training Review", "Service Coordination", "Safety Actions", "Project Handover")


class Command(BaseCommand):
    help = "Add demo records until each HR module contains at least 30 entries."

    @transaction.atomic
    def handle(self, *args, **options):
        self._fill_employees()
        demo_employees = list(
            Employee.objects.filter(
                Q(email__endswith="@example.com") | Q(email__startswith="employee", email__endswith="@example.test")
            ).order_by("employee_id")
        )

        self._fill_internships()
        self._fill_attendance(demo_employees)
        self._fill_payroll(demo_employees)
        self._fill_events()
        self._fill_meetings()
        self._fill_certificates(demo_employees)

        for model in (Employee, Internship, Attendance, Payroll, Event, Meeting, Certificate):
            self.stdout.write(f"{model.__name__}: {model.objects.count()}")

    @staticmethod
    def _employee_email(name):
        normalized = re.sub(r"[^a-z0-9]+", ".", name.lower()).strip(".")
        if not normalized:
            return "employee@example.com"
        return f"{normalized}@example.com"

    def _fill_employees(self):
        seeded_employee_filter = (
            Q(employee_id__startswith="DEMO-")
            | Q(employee_id__startswith="PMT-EMP-")
            | Q(email__endswith="@example.com")
            | Q(email__startswith="employee", email__endswith="@example.test")
            | Q(email__endswith="@example.test")
        )
        existing_seeded_count = Employee.objects.filter(seeded_employee_filter).count()
        existing_non_seeded_count = Employee.objects.exclude(seeded_employee_filter).count()
        seeded_target = max(existing_seeded_count, TARGET_COUNT - existing_non_seeded_count)
        existing_ids = Employee.objects.exclude(seeded_employee_filter).values_list("employee_id", flat=True)
        existing_employee_numbers = [
            int(employee_id[3:])
            for employee_id in existing_ids
            if employee_id.startswith("EMP") and employee_id[3:].isdigit()
        ]
        first_employee_number = max(
            max(existing_employee_numbers, default=0) + 1,
            existing_non_seeded_count + 1,
        )
        for index in range(1, seeded_target + 1):
            person, department, designation = EMPLOYEE_SEED_DATA[(index - 1) % len(EMPLOYEE_SEED_DATA)]
            employee_number = first_employee_number + index - 1
            values = {
                "employee_id": f"EMP{employee_number:03d}",
                "name": person,
                "department": department,
                "designation": designation,
                "experience": (index * 3) % 12,
                "email": self._employee_email(person),
                "phone": f"900{index:07d}",
                "location": LOCATIONS[(index - 1) % len(LOCATIONS)],
                "status": "Active" if index % 6 else "On Leave",
            }
            old_employee = Employee.objects.filter(
                Q(employee_id=f"DEMO-{index:03d}")
                | Q(employee_id=f"PMT-EMP-{index:03d}")
            ).first()
            if old_employee:
                for field, value in values.items():
                    setattr(old_employee, field, value)
                old_employee.save()
            else:
                Employee.objects.update_or_create(employee_id=values["employee_id"], defaults={
                    key: value for key, value in values.items() if key != "employee_id"
                })

    @staticmethod
    def _person_name(index):
        return EMPLOYEE_SEED_DATA[(index - 1) % len(EMPLOYEE_SEED_DATA)][0]

    def _fill_internships(self):
        seeded_names = tuple(
            self._person_name(index + 9)
            for index in range(1, TARGET_COUNT + 1)
        )
        seeded_filter = (
            Q(name__startswith="Demo ")
            | Q(name__contains=" | Cohort ")
            | Q(name__in=seeded_names)
        )
        seeded_records = list(Internship.objects.filter(seeded_filter).order_by("id"))
        seeded_target = max(len(seeded_records), TARGET_COUNT - (Internship.objects.count() - len(seeded_records)))
        durations = ("8 weeks", "10 weeks", "12 weeks", "16 weeks", "6 months")
        statuses = ("Active", "Completed", "Upcoming")

        for index in range(1, seeded_target + 1):
            values = {
                "name": self._person_name(index + 9),
                "college": COLLEGES[(index - 1) % len(COLLEGES)],
                "department": DEPARTMENTS[(index - 1) % len(DEPARTMENTS)],
                "duration": durations[(index - 1) % len(durations)],
                "mentor": self._person_name(index + 3),
                "status": statuses[(index - 1) % len(statuses)],
            }
            if index <= len(seeded_records):
                record = seeded_records[index - 1]
                for field, value in values.items():
                    setattr(record, field, value)
                record.save()
            else:
                Internship.objects.create(**values)

    def _fill_attendance(self, employees):
        attendance_statuses = (
            ("Present", time(8, 52), time(17, 45)),
            ("Present", time(9, 4), time(18, 2)),
            ("Late", time(9, 24), time(18, 5)),
            ("Half Day", time(9, 2), time(13, 0)),
            ("Remote", time(9, 0), time(17, 30)),
            ("On Leave", None, None),
        )
        index = 0
        first_day = date(2026, 10, 1)

        generated_records = Attendance.objects.filter(
            Q(employee__employee_id__startswith="DEMO-")
            | Q(employee__employee_id__startswith="PMT-EMP-")
            | Q(employee__email__endswith="@example.com")
            | Q(employee__email__startswith="employee", employee__email__endswith="@example.test")
            | Q(employee__email__endswith="@example.test"),
            date__range=(first_day, first_day + timedelta(days=30)),
            check_in=time(9, 0),
            check_out=time(18, 0),
            status="Present",
        ).order_by("date", "id")
        for index, record in enumerate(generated_records, start=1):
            status, check_in, check_out = attendance_statuses[(index - 1) % len(attendance_statuses)]
            record.status = status
            record.check_in = check_in
            record.check_out = check_out
            record.save(update_fields=("status", "check_in", "check_out"))

        index = 0
        while Attendance.objects.count() < TARGET_COUNT:
            employee = employees[index % len(employees)]
            record_date = first_day + timedelta(days=index)
            status, check_in, check_out = attendance_statuses[index % len(attendance_statuses)]
            Attendance.objects.get_or_create(
                employee=employee,
                date=record_date,
                defaults={
                    "check_in": check_in,
                    "check_out": check_out,
                    "status": status,
                },
            )
            index += 1

    def _fill_payroll(self, employees):
        seeded_employee_filter = (
            Q(employee__employee_id__startswith="DEMO-")
            | Q(employee__employee_id__startswith="PMT-EMP-")
            | Q(employee__email__endswith="@example.com")
            | Q(employee__email__startswith="employee", employee__email__endswith="@example.test")
            | Q(employee__email__endswith="@example.test")
        )
        seeded_payroll_filter = Q(month__startswith="Demo ") | seeded_employee_filter
        seeded_records = list(Payroll.objects.filter(seeded_payroll_filter).order_by("id"))
        seeded_target = max(len(seeded_records), TARGET_COUNT - (Payroll.objects.count() - len(seeded_records)))
        months = ("October",)

        for index in range(1, seeded_target + 1):
            employee = employees[(index - 1) % len(employees)]
            values = {
                "employee": employee,
                "month": months[(index - 1) // len(employees) % len(months)],
                "basic_salary": Decimal("38000.00") + Decimal(index * 1150),
                "allowances": Decimal("3200.00") + Decimal((index % 7) * 425),
                "deductions": Decimal("850.00") + Decimal((index % 5) * 175),
            }
            if index <= len(seeded_records):
                record = seeded_records[index - 1]
                for field, value in values.items():
                    setattr(record, field, value)
                record.save()
            else:
                Payroll.objects.create(**values)

    def _fill_events(self):
        seeded_filter = Q(name__startswith="Demo Event |") | Q(name__startswith="Panacea Event |")
        seeded_records = list(Event.objects.filter(seeded_filter).order_by("id"))
        seeded_target = max(len(seeded_records), TARGET_COUNT - (Event.objects.count() - len(seeded_records)))
        first_day = date(2026, 10, 10)
        event_types = ("Company Event", "Training", "Workshop", "Celebration", "Other")
        for index in range(1, seeded_target + 1):
            values = self._event_values(index, first_day, event_types)
            if index <= len(seeded_records):
                record = seeded_records[index - 1]
                for field, value in values.items():
                    setattr(record, field, value)
                record.save()
            else:
                Event.objects.create(**values)

    def _event_values(self, index, first_day, event_types):
        theme = EVENT_THEMES[(index - 1) // len(EVENT_FORMATS)]
        event_format = EVENT_FORMATS[(index - 1) % len(EVENT_FORMATS)]
        return {
            "name": f"Panacea Event | {theme} {event_format} {index:02d}",
            "event_type": event_types[(index - 1) % len(event_types)],
            "date": first_day + timedelta(days=index - 1),
            "time": time(9 + index % 8, (index * 7) % 60),
            "location": LOCATIONS[(index - 1) % len(LOCATIONS)] + " Facility",
            "organizer": self._person_name(index + 5),
            "description": f"Session {index:02d}: {event_format.lower()} for {theme.lower()}, with team discussion and documented follow-up actions.",
            "status": "Upcoming",
        }

    def _fill_meetings(self):
        seeded_filter = Q(title__startswith="Demo Meeting |") | Q(title__startswith="Panacea Meeting |")
        seeded_records = list(Meeting.objects.filter(seeded_filter).order_by("id"))
        seeded_target = max(len(seeded_records), TARGET_COUNT - (Meeting.objects.count() - len(seeded_records)))
        first_day = date(2026, 10, 10)
        meeting_types = ("HR Meeting", "Team Meeting", "Management Meeting", "Project Meeting", "Other")
        for index in range(1, seeded_target + 1):
            team = MEETING_TEAMS[(index - 1) // len(MEETING_TOPICS)]
            topic = MEETING_TOPICS[(index - 1) % len(MEETING_TOPICS)]
            values = {
                "title": f"Panacea Meeting | {team} | {topic} {index:02d}",
                "meeting_type": meeting_types[(index - 1) % len(meeting_types)],
                "date": first_day + timedelta(days=index - 1),
                "time": time(10 + index % 7, (index * 11) % 60),
                "location": f"{LOCATIONS[(index - 1) % len(LOCATIONS)]} {team} Room",
                "organizer": self._person_name(index + 7),
                "participants": f"{team} representatives and invited reviewers, session {index:02d}",
                "agenda": f"Review {topic.lower()} for {team.lower()}, assign owners, and record the next milestone for session {index:02d}.",
                "status": "Scheduled",
            }
            if index <= len(seeded_records):
                record = seeded_records[index - 1]
                for field, value in values.items():
                    setattr(record, field, value)
                record.save()
            else:
                Meeting.objects.create(**values)

    def _fill_certificates(self, employees):
        seeded_filter = Q(certificate_number__startswith="DEMO-CERT-") | Q(certificate_number__startswith="PMT-CERT-")
        seeded_records = list(Certificate.objects.filter(seeded_filter).order_by("id"))
        seeded_target = max(len(seeded_records), TARGET_COUNT - (Certificate.objects.count() - len(seeded_records)))
        certificate_types = tuple(choice[0] for choice in Certificate.CERTIFICATE_TYPES)
        issuers = ("Human Resources", "Training Office", "People Operations", "Clinical Operations")

        for index in range(1, seeded_target + 1):
            employee = employees[(index - 1) % len(employees)]
            if index == 1:
                employee = next(
                    (person for person in employees if person.name == "Dhanush B M"),
                    employee,
                )
            certificate_type = certificate_types[(index - 1) % len(certificate_types)]
            values = {
                "certificate_number": f"PMT-CERT-{index:03d}",
                "employee": employee,
                "certificate_type": certificate_type,
                "issue_date": date(2026, 1, 1) + timedelta(days=index - 1),
                "description": f"{certificate_type} prepared for {employee.name}; issue reference {index:03d}.",
                "issued_by": issuers[(index - 1) % len(issuers)],
                "status": "Issued",
            }
            if index <= len(seeded_records):
                record = seeded_records[index - 1]
                for field, value in values.items():
                    setattr(record, field, value)
                record.save()
            else:
                Certificate.objects.create(**values)