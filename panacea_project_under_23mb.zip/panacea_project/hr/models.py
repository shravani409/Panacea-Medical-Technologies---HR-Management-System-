from django.db import models


class Employee(models.Model):

    employee_id = models.CharField(
        max_length=20,
        unique=True
    )

    name = models.CharField(
        max_length=100
    )

    department = models.CharField(
        max_length=100
    )

    designation = models.CharField(
        max_length=100
    )

    experience = models.IntegerField(
        default=0
    )

    email = models.EmailField(
        blank=True
    )

    phone = models.CharField(
        max_length=20,
        blank=True
    )

    location = models.CharField(
        max_length=100,
        default="Bengaluru"
    )

    status = models.CharField(
        max_length=30,
        default="Active"
    )

    def __str__(self):
        return f"{self.employee_id} - {self.name}"


class Internship(models.Model):

    name = models.CharField(
        max_length=100
    )

    college = models.CharField(
        max_length=150
    )

    department = models.CharField(
        max_length=100
    )

    duration = models.CharField(
        max_length=50
    )

    mentor = models.CharField(
        max_length=100
    )

    status = models.CharField(
        max_length=30,
        default="Active"
    )

    def __str__(self):
        return self.name


class Attendance(models.Model):

    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE
    )

    date = models.DateField()

    check_in = models.TimeField(
        null=True,
        blank=True
    )

    check_out = models.TimeField(
        null=True,
        blank=True
    )

    status = models.CharField(
        max_length=30,
        default="Present"
    )

    def __str__(self):
        return f"{self.employee.name} - {self.date}"


class Payroll(models.Model):

    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE
    )

    basic_salary = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )

    allowances = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0
    )

    deductions = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0
    )

    month = models.CharField(
        max_length=20
    )

    @property
    def net_salary(self):
        return (
            self.basic_salary
            + self.allowances
            - self.deductions
        )

    def __str__(self):
        return self.employee.name


class Event(models.Model):

    EVENT_TYPES = [
        ("Company Event", "Company Event"),
        ("Training", "Training"),
        ("Workshop", "Workshop"),
        ("Celebration", "Celebration"),
        ("Other", "Other"),
    ]

    name = models.CharField(
        max_length=150
    )

    event_type = models.CharField(
        max_length=50,
        choices=EVENT_TYPES,
        default="Company Event"
    )

    date = models.DateField()

    time = models.TimeField()

    location = models.CharField(
        max_length=150
    )

    organizer = models.CharField(
        max_length=100
    )

    description = models.TextField(
        blank=True
    )

    status = models.CharField(
        max_length=30,
        default="Upcoming"
    )

    def __str__(self):
        return self.name


class Meeting(models.Model):

    MEETING_TYPES = [
        ("HR Meeting", "HR Meeting"),
        ("Team Meeting", "Team Meeting"),
        ("Management Meeting", "Management Meeting"),
        ("Project Meeting", "Project Meeting"),
        ("Other", "Other"),
    ]

    title = models.CharField(
        max_length=150
    )

    meeting_type = models.CharField(
        max_length=50,
        choices=MEETING_TYPES,
        default="Team Meeting"
    )

    date = models.DateField()

    time = models.TimeField()

    location = models.CharField(
        max_length=150
    )

    organizer = models.CharField(
        max_length=100
    )

    participants = models.TextField(
        blank=True
    )

    agenda = models.TextField(
        blank=True
    )

    status = models.CharField(
        max_length=30,
        default="Scheduled"
    )

    def __str__(self):
        return self.title


class Certificate(models.Model):

    CERTIFICATE_TYPES = [
        ("Experience Certificate", "Experience Certificate"),
        ("Internship Certificate", "Internship Certificate"),
        ("Training Certificate", "Training Certificate"),
        ("Appreciation Certificate", "Appreciation Certificate"),
        ("Other", "Other"),
    ]

    certificate_number = models.CharField(
        max_length=50,
        unique=True
    )

    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE
    )

    certificate_type = models.CharField(
        max_length=100,
        choices=CERTIFICATE_TYPES
    )

    issue_date = models.DateField()

    description = models.TextField(
        blank=True
    )

    issued_by = models.CharField(
        max_length=100
    )

    status = models.CharField(
        max_length=30,
        default="Issued"
    )