from django.test import TestCase
from django.urls import reverse
from django.core.management import call_command
from django.contrib.auth import get_user_model

from .models import (
    Employee,
    Internship,
    Attendance,
    Payroll,
    Event,
    Meeting,
    Certificate,
)


class HRModelTests(TestCase):

    def setUp(self):

        self.employee = Employee.objects.create(
            employee_id="TEST001",
            name="Test Employee",
            department="HR",
            designation="HR Executive",
            experience=2,
            email="test@example.com",
            phone="9876543210",
            location="Bengaluru",
            status="Active",
        )


    def test_employee_created(self):

        self.assertEqual(
            Employee.objects.count(),
            1
        )

        self.assertEqual(
            self.employee.name,
            "Test Employee"
        )


class HRDemoSeedCommandTests(TestCase):

    def test_first_certificate_is_assigned_to_dhanush_b_m(self):
        call_command("seed_hr_demo", verbosity=0)

        certificate = Certificate.objects.get(certificate_number="PMT-CERT-001")
        self.assertEqual(certificate.employee.name, "Dhanush B M")

    def test_command_updates_legacy_employee_email_format(self):
        Employee.objects.create(
            employee_id="EMP006",
            name="Ishaan Rao",
            department="Engineering",
            designation="Systems Engineer",
            experience=2,
            email="employee006@example.test",
            phone="900000006",
            location="Bengaluru",
            status="Active",
        )

        call_command("seed_hr_demo", verbosity=0)

        self.assertEqual(Employee.objects.get(employee_id="EMP006").email, "ishaan.rao@example.com")

    def test_command_fills_each_module_and_is_repeatable(self):
        call_command("seed_hr_demo", verbosity=0)
        first_counts = [
            Employee.objects.count(),
            Internship.objects.count(),
            Attendance.objects.count(),
            Payroll.objects.count(),
            Event.objects.count(),
            Meeting.objects.count(),
            Certificate.objects.count(),
        ]
        self.assertEqual(
            Employee.objects.filter(email__endswith="@example.com").values("name").distinct().count(),
            30,
        )
        self.assertEqual(
            Employee.objects.order_by("employee_id").first().email,
            "aarav.rao@example.com",
        )
        self.assertTrue(Employee.objects.filter(employee_id="EMP001").exists())
        self.assertTrue(Employee.objects.filter(employee_id="EMP030").exists())
        self.assertEqual(
            Internship.objects.filter(name__contains=" | Cohort ").exclude(name__startswith="Internship ").count(),
            30,
        )
        self.assertEqual(
            Event.objects.filter(name__startswith="Panacea Event |").values("description").distinct().count(),
            30,
        )
        self.assertEqual(
            Meeting.objects.filter(title__startswith="Panacea Meeting |").values("agenda").distinct().count(),
            30,
        )
        self.assertEqual(
            Certificate.objects.filter(certificate_number__startswith="PMT-CERT-").values("description").distinct().count(),
            30,
        )
        self.assertFalse(Employee.objects.filter(employee_id__startswith="PMT-EMP-", name__icontains="demo").exists())
        self.assertFalse(Internship.objects.filter(name__icontains="demo").exists())
        self.assertGreater(
            Attendance.objects.values("status").distinct().count(),
            1,
        )

        call_command("seed_hr_demo", verbosity=0)
        second_counts = [
            Employee.objects.count(),
            Internship.objects.count(),
            Attendance.objects.count(),
            Payroll.objects.count(),
            Event.objects.count(),
            Meeting.objects.count(),
            Certificate.objects.count(),
        ]

        self.assertTrue(all(count >= 30 for count in first_counts))
        self.assertEqual(first_counts, second_counts)


class HRPortalAccessTests(TestCase):

    def test_only_requested_credentials_open_the_portal(self):
        for username, password in (
            ("wrong", "shravani"),
            ("panacea", "wrong"),
            ("Panacea", "shravani"),
        ):
            with self.subTest(username=username, password=password):
                response = self.client.post(
                    reverse("hr_login"),
                    {"username": username, "password": password},
                )
                self.assertContains(response, "Invalid username or password.", status_code=200)
                self.assertFalse(self.client.session.get("_auth_user_id"))

        response = self.client.post(
            reverse("hr_login"),
            {"username": "panacea", "password": "shravani"},
        )
        self.assertRedirects(response, reverse("hr_dashboard"))
        self.assertEqual(self.client.get(reverse("hr_dashboard")).status_code, 200)

    def test_hr_pages_require_login_for_direct_url_access(self):
        protected_urls = (
            "hr_dashboard",
            "employees",
            "payroll",
            "attendance",
            "internships",
            "events",
            "meetings",
            "certificates",
            "certificate_view",
            "reports",
            "company_reports",
        )

        for url_name in protected_urls:
            with self.subTest(url_name=url_name):
                url = reverse(url_name, args=[1]) if url_name == "certificate_view" else reverse(url_name)
                response = self.client.get(url)
                self.assertEqual(response.status_code, 302)
                self.assertTrue(response.url.startswith(reverse("hr_login")))

    def test_other_authenticated_users_cannot_access_hr_pages(self):
        other_user = get_user_model().objects.create_user(
            username="another-user",
            password="not-the-hr-password",
        )
        self.client.force_login(other_user)

        response = self.client.get(reverse("hr_dashboard"))
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith(reverse("hr_login")))

        response = self.client.get(reverse("hr_login"))
        self.assertEqual(response.status_code, 200)

    def test_existing_panacea_session_still_requires_hr_login(self):
        portal_user = get_user_model().objects.create_user(
            username="panacea",
            password="another-password",
        )
        self.client.force_login(portal_user)

        response = self.client.get(reverse("hr_dashboard"))
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith(reverse("hr_login")))