from django.contrib import admin

from .models import (
    Employee,
    Internship,
    Attendance,
    Payroll,
    Event,
    Meeting,
    Certificate,
)


admin.site.register(Employee)
admin.site.register(Internship)
admin.site.register(Attendance)
admin.site.register(Payroll)
admin.site.register(Event)
admin.site.register(Meeting)
admin.site.register(Certificate)