import secrets
from functools import wraps

from django.contrib.auth import get_user_model, login, logout
from django.contrib.auth.views import redirect_to_login
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404

from .models import (
    Employee,
    Payroll,
    Attendance,
    Internship,
    Event,
    Meeting,
    Certificate,
)

HR_PORTAL_USERNAME = "panacea"
HR_PORTAL_PASSWORD = "shravani"


def _is_hr_portal_user(user):
    return user.is_authenticated and user.get_username() == HR_PORTAL_USERNAME


def hr_portal_required(view_func):
    @wraps(view_func)
    def wrapped_view(request, *args, **kwargs):
        if (
            _is_hr_portal_user(request.user)
            and request.session.get("hr_portal_authenticated")
        ):
            return view_func(request, *args, **kwargs)
        return redirect_to_login(request.get_full_path(), login_url="/hr/login/")

    return wrapped_view


def home(request):

    return render(
        request,
        "home.html"
    )


def hr_login(request):

    if (
        _is_hr_portal_user(request.user)
        and request.session.get("hr_portal_authenticated")
    ):

        return redirect("hr_dashboard")

    error = None

    if request.method == "POST":

        username = request.POST.get("username", "")
        password = request.POST.get("password", "")

        valid_username = secrets.compare_digest(
            username.encode("utf-8"),
            HR_PORTAL_USERNAME.encode("utf-8"),
        )
        valid_password = secrets.compare_digest(
            password.encode("utf-8"),
            HR_PORTAL_PASSWORD.encode("utf-8"),
        )

        if valid_username and valid_password:
            user_model = get_user_model()
            user, created = user_model.objects.get_or_create(
                username=HR_PORTAL_USERNAME,
            )
            if created:
                user.set_unusable_password()
                user.save(update_fields=["password"])

            if user.is_active:
                login(
                    request,
                    user,
                    backend="django.contrib.auth.backends.ModelBackend",
                )
                request.session["hr_portal_authenticated"] = True
                return redirect("hr_dashboard")

        error = "Invalid username or password."

    return render(
        request,
        "hr/login.html",
        {
            "error": error,
        },
    )


@hr_portal_required
def hr_logout(request):

    logout(request)

    return redirect("hr_login")


@hr_portal_required
def dashboard(request):

    context = {
        "employee_count": Employee.objects.count(),
        "intern_count": Internship.objects.count(),
        "attendance_count": Attendance.objects.count(),
        "payroll_count": Payroll.objects.count(),
        "event_count": Event.objects.count(),
        "meeting_count": Meeting.objects.count(),
        "certificate_count": Certificate.objects.count(),
    }

    return render(
        request,
        "hr/dashboard.html",
        context,
    )


@hr_portal_required
def employees(request):

    search = request.GET.get(
        "search",
        ""
    )

    employee_list = Employee.objects.all()

    if search:

        employee_list = employee_list.filter(
            Q(name__icontains=search)
            | Q(employee_id__icontains=search)
            | Q(department__icontains=search)
        )

    return render(
        request,
        "hr/employees.html",
        {
            "employees": employee_list,
            "search": search,
        },
    )


@hr_portal_required
def payroll(request):

    payroll_list = Payroll.objects.select_related(
        "employee"
    )

    return render(
        request,
        "hr/payroll.html",
        {
            "payroll": payroll_list,
        },
    )


@hr_portal_required
def attendance(request):

    attendance_list = Attendance.objects.select_related(
        "employee"
    )

    return render(
        request,
        "hr/attendance.html",
        {
            "attendance": attendance_list,
        },
    )


@hr_portal_required
def internships(request):

    internship_list = Internship.objects.all()

    return render(
        request,
        "hr/internships.html",
        {
            "internships": internship_list,
        },
    )


@hr_portal_required
def events(request):

    event_list = Event.objects.all().order_by(
        "date",
        "time"
    )

    return render(
        request,
        "hr/events.html",
        {
            "events": event_list,
        },
    )


@hr_portal_required
def meetings(request):

    meeting_list = Meeting.objects.all().order_by(
        "date",
        "time"
    )

    return render(
        request,
        "hr/meetings.html",
        {
            "meetings": meeting_list,
        },
    )


@hr_portal_required
def certificates(request):

    certificate_list = Certificate.objects.select_related(
        "employee"
    ).order_by(
        "-issue_date"
    )

    return render(
        request,
        "hr/certificates.html",
        {
            "certificates": certificate_list,
        },
    )


@hr_portal_required
def certificate_view(request, certificate_id):

    certificate = get_object_or_404(
        Certificate,
        id=certificate_id
    )

    return render(
        request,
        "hr/certificate_view.html",
        {
            "certificate": certificate
        }
    )


@hr_portal_required
def reports(request):

    context = {
        "employee_count": Employee.objects.count(),
        "internship_count": Internship.objects.count(),
        "attendance_count": Attendance.objects.count(),
        "payroll_count": Payroll.objects.count(),
        "event_count": Event.objects.count(),
        "meeting_count": Meeting.objects.count(),
        "certificate_count": Certificate.objects.count(),
    }

    return render(
        request,
        "hr/reports.html",
        context
    )


@hr_portal_required
def company_reports(request):

    context = {
        "annual_revenue": "18.6",
        "annual_expenses": "11.2",
        "annual_profit": "7.4",
        "total_orders": "1,248",
    }

    return render(
        request,
        "hr/company_reports.html",
        context
    )