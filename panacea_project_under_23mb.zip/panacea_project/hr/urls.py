from django.urls import path

from . import views


urlpatterns = [

    path(
        "login/",
        views.hr_login,
        name="hr_login",
    ),

    path(
        "logout/",
        views.hr_logout,
        name="hr_logout",
    ),

    path(
        "",
        views.dashboard,
        name="hr_dashboard",
    ),

    path(
        "employees/",
        views.employees,
        name="employees",
    ),

    path(
        "payroll/",
        views.payroll,
        name="payroll",
    ),

    path(
        "attendance/",
        views.attendance,
        name="attendance",
    ),

    path(
        "internships/",
        views.internships,
        name="internships",
    ),

    path(
        "events/",
        views.events,
        name="events",
    ),

    path(
        "meetings/",
        views.meetings,
        name="meetings",
    ),

    path(
        "certificates/",
        views.certificates,
        name="certificates",
    ),

    path(
        "certificates/<int:certificate_id>/",
        views.certificate_view,
        name="certificate_view",
    ),

    path(
        "reports/",
        views.reports,
        name="reports",
    ),

    path(
        "company-reports/",
        views.company_reports,
        name="company_reports",
    ),

]